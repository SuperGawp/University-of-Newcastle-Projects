STUDENT NUMBER: C3360071
ALL FILES: budget.xml, honeymoon.xml, template.xml, holiday-xslt.xsl, index.html, contact.html, dataColl.html, privacyPolicy.html, terms&condition.html, style.css, README.txt, assignment coversheet and an images folder (contains all the images used)



background image link: https://images.unsplash.com/photo-1549880338-65ddcdfd017b?ixlib=rb-1.2.1&auto=format&fit=crop&w=750&q=80

HONEYMOON
Elegant Europe! - https://www.tourradar.com/t/82996#p=2_
	image link: https://cdn.tourradar.com/s3/tour/1500x800/82996_12d3cf9a.jpg

japan - https://www.zicasso.com/luxury-vacation-japan-tours/exploring-kyushu-shikoku-islands-tour
	image link: https://res.cloudinary.com/zicasso/image/fetch/c_fill,f_auto,g_custom,q_auto,w_764/https://images.zicasso.com/234b72742189b4b1d44bea7240cfe327.jpg

fiji - https://www.besthoneymoonpackages.com.au/honeymoon-packages/best-fiji-honeymoon-packages/shangri-las-fijian-resort-spa/
	image link: https://q-ak.bstatic.com/images/hotel/max1024x768/191/191403036.jpg

BUDGET
Bali - https://www.flightcentre.com.au/product/12973530
	image link: https://www.flightcentre.com.au/cms_images/web_images/blog/fc/gunung_kawi.jpg

Gold Coast - https://travel.virginaustralia.com/au/holidays/gold-coast?field_deal_search_type_value=flight_hotel_ticket&Submit=Go
	image link: https://www.telegraph.co.uk/content/dam/business/spark/gold-coast-council/surfers-dusk-gold-coast.jpg

New Zealand - https://www.flightcentre.com.au/product/13148601
	image link: https://www.firstlighttravel.com/sites/default/files/west-coast-glacier.jpg

ENTERNAL LINK: https://www.w3schools.com/

Navigation Bar: https://www.w3schools.com/howto/howto_js_responsive_navbar_dropdown.asp

TERMS & CONDITION: https://termly.io/resources/templates/terms-and-conditions-template/

HTML TO TEXT FOR T&C: https://www.phpjunkyard.com/tools/html-to-text.php

PRIVACY POLICY: https://visser.io/tools/living-in-australia/privacy-policy-generator/

EMAIL VALIDATION HELP: https://uncleseng.ml/javascript/

